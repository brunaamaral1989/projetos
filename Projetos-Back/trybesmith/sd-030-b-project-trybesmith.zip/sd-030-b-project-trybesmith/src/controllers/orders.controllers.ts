import { Request, Response } from 'express';
import services from '../services';
import mapStatusHTTP from '../utils/mapStatusHTTP';

const getAllOrders = async (_req: Request, res: Response) => {
  const result = await services.getAllOrders();
  return res.status(mapStatusHTTP(result.status)).json(result.data);
};

const newOrders = async (req: Request, res: Response) => {
  const { userId, productIds } = req.body;
  const checkUser = await services.getUserById(userId);
  if (checkUser.status !== 'SUCCESSFUL') {
    return res.status(mapStatusHTTP(checkUser.status)).json(checkUser.data);
  }
  const result = await services.newOrders(userId, productIds);
  return res.status(mapStatusHTTP(result.status)).json(result.data);
};

export default { getAllOrders, newOrders };