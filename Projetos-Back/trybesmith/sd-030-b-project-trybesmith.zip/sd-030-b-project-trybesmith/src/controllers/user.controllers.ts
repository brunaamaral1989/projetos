import { Request, Response } from 'express';
import services from '../services';
import mapStatusHTTP from '../utils/mapStatusHTTP';

const login = async (req: Request, res: Response) => {
  const { username, password } = req.body;
  const result = await services.login(username, password);
  return res.status(mapStatusHTTP(result.status)).json(result.data);
};

export default { login };