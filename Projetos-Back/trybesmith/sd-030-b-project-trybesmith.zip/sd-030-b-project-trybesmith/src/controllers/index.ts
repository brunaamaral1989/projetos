import productController from './products.controllers';
import ordersControllers from './orders.controllers';
import userControllers from './user.controllers';

export default {
  newProducts: productController.newProducts,
  getAllProducts: productController.getAllProducts,
  getAllOrders: ordersControllers.getAllOrders,
  login: userControllers.login,
  newOrders: ordersControllers.newOrders,
};