import { Request, Response } from 'express';
import services from '../services';
import mapStatusHTTP from '../utils/mapStatusHTTP';

const newProducts = async (req: Request, res: Response) => {
  const result = await services.newProducts(req.body);
  return res.status(mapStatusHTTP(result.status)).json(result.data);
};

const getAllProducts = async (_req: Request, res: Response) => {
  const result = await services.getAllProducts();
  return res.status(mapStatusHTTP(result.status)).json(result.data);
};

export default {
  newProducts,
  getAllProducts,
};