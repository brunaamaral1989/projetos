import productsServices from './products.services';
import ordersServices from './orders.services';
import userServices from './user.services';

export default {
  newProducts: productsServices.newProducts,
  getAllProducts: productsServices.getAllProducts,
  getProductById: productsServices.getProductById,
  getAllOrders: ordersServices.getAllOrders,
  login: userServices.login,
  getUserById: userServices.getUserById,
  newOrders: ordersServices.newOrders,
};