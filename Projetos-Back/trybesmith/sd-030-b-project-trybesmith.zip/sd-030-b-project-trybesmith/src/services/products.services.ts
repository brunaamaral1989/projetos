import ProductModel from '../database/models/product.model';
import { Product, ProductService } from '../types/Product';
import { Service } from '../types/Service';

const newProducts = async (product: Product): Promise<Service<Product>> => {
  const newProduct = await ProductModel.create(product);
  const { orderId, ...result } = newProduct.toJSON();
  return { status: 'CREATED', data: result };
};

const getAllProducts = async (): Promise<Service<Product>> => {
  const products = await ProductModel.findAll();
  const result = products.map((product) => product.toJSON());
  return { status: 'SUCCESSFUL', data: result };
};

const getProductById = async (id: number): Promise<Service<ProductService>> => {
  const products = await ProductModel.findByPk(id);
  const result = products?.toJSON();
  if (result) {
    return { status: 'SUCCESSFUL', data: result };
  }
  return { status: 'NOT_FOUND', data: { message: '"productId" not found' } };
};

export default {
  newProducts,
  getAllProducts,
  getProductById,
};