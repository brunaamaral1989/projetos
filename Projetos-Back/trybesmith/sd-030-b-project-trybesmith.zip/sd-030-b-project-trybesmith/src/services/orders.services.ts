import OrderModel from '../database/models/order.model';
import { Service } from '../types/Service';
import { CreateOrder, Order } from '../types/Order';
import ProductModel from '../database/models/product.model';
import db from '../database/models';

const getAllOrders = async (): Promise<Service<Order>> => {
  const modelResponse = await OrderModel.findAll({
    include: [
      {
        model: ProductModel,
        as: 'productIds',
        attributes: ['id'],
      },
    ],
  });
  const orders = modelResponse.map((order) => order.toJSON());
  const result = orders.map((order) => {
    const productIds = (order.productIds as { id: number }[]).map((product) => product.id);
    return { ...order, productIds };
  });
  return { status: 'SUCCESSFUL', data: result };
};
const newOrders = async (userId: number, productIds: number[]): Promise<Service<CreateOrder>> => {
  try {
    await db.transaction(async (t) => {
      const newOrder = await OrderModel.create({ userId }, { transaction: t });
      const updateProducts = productIds.map(async (productId) => {
        await ProductModel.update(
          { orderId: newOrder.dataValues.id },
          { where: { id: productId }, transaction: t },
        );
      });
      await Promise.all(updateProducts);
    });
    return { status: 'CREATED', data: { userId, productIds } };
  } catch (error) {
    return { status: 'INTERNAL_SERVER_ERROR', data: { message: 'Something went wrong' } };
  }
};

export default { getAllOrders, newOrders };