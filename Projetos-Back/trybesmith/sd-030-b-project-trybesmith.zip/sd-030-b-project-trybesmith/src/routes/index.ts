import LoginRouter from './login.routes';
import OrdersRouter from './orders.routes';
import ProductsRouter from './products.routes';

export {
  LoginRouter,
  OrdersRouter,
  ProductsRouter,
};