import StatusHTTP from '../types/StatusHTTP';

const mapStatusHTTP = (status: keyof typeof StatusHTTP): number => StatusHTTP[status];

export default mapStatusHTTP;