import sinon from 'sinon';
import chai, { expect } from 'chai';
import chaiHttp from 'chai-http';
import ProductModel from '../../../src/database/models/product.model';
import app from '../../../src/app';
import { productMock, createdProduct, sentProduct, getAllProducts } from '../../mocks/products.mocks';

chai.use(chaiHttp);

describe('Testes Products', function () { 
  beforeEach(function () { sinon.restore(); });
  
  it('Valida se retorna 201 ao criar novo produto', async function () {
    sinon.stub(ProductModel, 'create').resolves(ProductModel.build(productMock));
    const res = await chai.request(app).post('/products').send(sentProduct);
    expect(res).to.have.status(201);
    expect(res.body).to.be.deep.equal(createdProduct);
  });

  it('Valida se retorna status 200 ao pesquisar produto', async function () {
    sinon.stub(ProductModel, 'findAll').resolves(getAllProducts.map((product) => ProductModel.build(product)));
    const res = await chai.request(app).get('/products').send();
    expect(res).to.have.status(200);
    expect(res.body).to.be.deep.equal(getAllProducts);
  });
});
