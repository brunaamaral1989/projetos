import sinon from 'sinon';
import chai, { expect } from 'chai';
import chaiHttp from 'chai-http';
import OrderModel from '../../../src/database/models/order.model';
import ProductModel from '../../../src/database/models/product.model';
import app from '../../../src/app';
import { validToken } from '../../mocks/token.mocks';
import UserModel from '../../../src/database/models/user.model';
import { mockedUserFromModel } from '../../mocks/user.mocks';
import { productMock } from '../../mocks/products.mocks';
import { getAllOrdersFromModel, getAllOrdersFromService } from '../../mocks/order.mocks';

chai.use(chaiHttp);

describe('Testes Order', function () {
  beforeEach(function () {
    sinon.restore();
  });

  it('Valida se retorna status 201 ao criar pedido', async function () {
    sinon.stub(OrderModel, 'create').resolves(OrderModel.build({ id: 1, userId: 1 }));
    sinon.stub(ProductModel, 'update').resolves([1]);
    sinon.stub(UserModel, 'findByPk').resolves(UserModel.build(mockedUserFromModel));
    sinon.stub(ProductModel, 'findByPk').resolves(ProductModel.build(productMock));

    const res = await chai
      .request(app)
      .post('/orders')
      .set({ Authorization: `Harry ${validToken}` })
      .send({ userId: 1, productIds: [1, 2] });

    expect(res).to.have.status(201);
    expect(res.body).to.deep.equal({ userId: 1, productIds: [1, 2] });
  });

  it('Valida se retorna status 401 se o token nao for enviado', async function () {
    sinon.stub(OrderModel, 'create').resolves(OrderModel.build({ id: 1, userId: 1 }));
    sinon.stub(ProductModel, 'update').resolves([1]);
    sinon.stub(UserModel, 'findByPk').resolves(UserModel.build(mockedUserFromModel));
    sinon.stub(ProductModel, 'findByPk').resolves(ProductModel.build(productMock));

    const res = await chai
      .request(app)
      .post('/orders')
      .send({ userId: 1, productIds: [1, 2] });

    expect(res).to.have.status(401);
    expect(res.body).to.deep.equal({ message: 'Token not found' });
  });

  it('Valida se retorna status 401 se o token for invalido', async function () {
    sinon.stub(OrderModel, 'create').resolves(OrderModel.build({ id: 1, userId: 1 }));
    sinon.stub(ProductModel, 'update').resolves([1]);
    sinon.stub(UserModel, 'findByPk').resolves(UserModel.build(mockedUserFromModel));
    sinon.stub(ProductModel, 'findByPk').resolves(ProductModel.build(productMock));

    const res = await chai
      .request(app)
      .post('/orders')
      .set({ Authorization: `Harry 123456` })
      .send({ userId: 1, productIds: [1, 2] });

    expect(res).to.have.status(401);
    expect(res.body).to.deep.equal({ message: 'Invalid token' });
  });

  it('Valida se retorna status 401 se o usuario for invalido', async function () {
    sinon.stub(OrderModel, 'create').resolves(OrderModel.build({ id: 1, userId: 1 }));
    sinon.stub(ProductModel, 'update').resolves([1]);
    sinon.stub(UserModel, 'findByPk').resolves(null);
    sinon.stub(ProductModel, 'findByPk').resolves(ProductModel.build(productMock));

    const res = await chai
      .request(app)
      .post('/orders')
      .set({ Authorization: `Harry ${validToken}` })
      .send({ userId: 1, productIds: [1, 2] });

    expect(res).to.have.status(404);
    expect(res.body).to.have.property('message').equal('"userId" not found');
  });

  it('Valida se retorna status 200 e um array de pedidos', async function () {
    sinon.stub(OrderModel, 'findAll').resolves(
      getAllOrdersFromModel.map((order) =>
        OrderModel.build(order, {
          include: [
            {
              model: ProductModel,
              as: 'productIds',
              attributes: ['id'],
            },
          ],
        }),
      ),
    );
    const res = await chai.request(app).get('/orders').send();
    expect(res).to.have.status(200);
    expect(res.body).to.be.deep.equal(getAllOrdersFromService);
  });

});
