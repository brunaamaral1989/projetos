export const productMock = { id: 1, name: 'Martelo de Thor', price: '30', orderId: 1 };

export const sentProduct = { name: 'Pedra Filosofal', price: '200', orderId: 1 };

export const createdProduct = { id: 1, name: 'Martelo de Thor', price: '30' };

export const getAllProducts = [
  {
    "id": 1,
    "name": "Pedra Filosofal",
    "price": "20 gold",
    "orderId": 1
  },
  {
    "id": 2,
    "name": "Lança do Destino",
    "price": "100 diamond",
    "orderId": 1
  }
];