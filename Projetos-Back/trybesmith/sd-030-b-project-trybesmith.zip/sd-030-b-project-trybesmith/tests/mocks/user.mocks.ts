export const mockedUserFromModel = {
    id: 1,
    username: 'Harry',
    vocation: 'Bruxo',
    level: 20,
    password: 'F8u6<*S0xWeJ',
  };