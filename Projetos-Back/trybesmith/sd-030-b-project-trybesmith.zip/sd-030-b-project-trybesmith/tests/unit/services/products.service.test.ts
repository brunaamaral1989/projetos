import { expect } from 'chai';
import sinon from 'sinon';

describe('ProductsService', function () {
  beforeEach(function () { sinon.restore(); });

});
